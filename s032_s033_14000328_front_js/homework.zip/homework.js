function change_image_size(x) {
    let div_img = document.getElementById("img")
    div_img.style.width = x + "%"

}